/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.entities;

/**
 *
 * @author karim
 */
public class Commande {
    float id;
    String description;
    String nom;
    String prenom;
    String etat;
    float userid;
    
    public Commande(float id, String description, String nom, String prenom, String etat,float userid) {
        this.id = id;
        this.description = description;
        this.nom = nom;
        this.prenom = prenom;
        this.etat = etat;
        this.userid = userid;
    }

    public Commande(String description, String nom, String prenom,float userid) {
        this.description = description;
        this.nom = nom;
        this.prenom = prenom;
        this.userid = userid;
        
    }

    public Commande() {
    }

    public float getUserid() {
        return userid;
    }

    public void setUserid(float userid) {
        this.userid = userid;
    }

    public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }
    
    
    
}
