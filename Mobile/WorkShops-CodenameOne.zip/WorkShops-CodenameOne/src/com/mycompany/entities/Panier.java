/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.entities;

/**
 *
 * @author karim
 */
public class Panier {
    
    float id;
    String produit;
    String quantite;

    public Panier(float id, String produit, String quantite) {
        this.id = id;
        this.produit = produit;
        this.quantite = quantite;
    }

    public Panier(String produit, String quantite) {
        this.produit = produit;
        this.quantite = quantite;
    }

    public Panier() {
    }

    public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }

    public String getProduit() {
        return produit;
    }

    public void setProduit(String produit) {
        this.produit = produit;
    }

    public String getQuantite() {
        return quantite;
    }

    public void setQuantite(String quantite) {
        this.quantite = quantite;
    }
    
    
}
