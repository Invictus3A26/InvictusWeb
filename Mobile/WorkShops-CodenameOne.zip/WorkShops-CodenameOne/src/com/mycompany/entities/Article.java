/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.entities;

/**
 *
 * @author nouri
 */
public class Article {
     private float id;
     private String titre;
     private String description;
     private String image;

    public float getId() {
        return id;
    }

    public String getTitre() {
        return titre;
    }

    public String getDescription() {
        return description;
    }

    public String getImage() {
        return image;
    }

    public void setId(float id) {
        this.id = id;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Article(float id, String titre, String description, String image) {
        this.id = id;
        this.titre = titre;
        this.description = description;
        this.image = image;
    }

    public Article() {
    }

    public Article( String titre, String description) {
       
        this.titre = titre;
        this.description = description;
    }

    public Article(float id, String titre, String description) {
        this.id = id;
        this.titre = titre;
        this.description = description;
    }
   
}

