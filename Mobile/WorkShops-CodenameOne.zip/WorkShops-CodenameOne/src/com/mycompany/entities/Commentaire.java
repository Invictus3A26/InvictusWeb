/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.entities;

/**
 *
 * @author MSI
 */
public class Commentaire {
    float id ; 
String contenu ; 
float article ; 
float user ; 

    public Commentaire(String contenu, float article, float user) {
        this.contenu = contenu;
        this.article = article;
        this.user = user;
    }

    public Commentaire(float id, String contenu, float article, float user) {
        this.id = id;
        this.contenu = contenu;
        this.article = article;
        this.user = user;
    }

    public Commentaire() {
    }

    public float getUser() {
        return user;
    }

    public void setUser(float user) {
        this.user = user;
    }


    public float getId() {
        return id;
    }

    public void setId(float id) {
        this.id = id;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

    public float getArticle() {
        return article;
    }

    public void setArticle(float article) {
        this.article = article;
    }

}
