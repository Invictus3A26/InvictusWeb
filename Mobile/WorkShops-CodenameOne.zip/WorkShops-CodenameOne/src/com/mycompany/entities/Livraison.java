/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.entities;
import java.util.Date;

/**
 *
 * @author karim
 */
public class Livraison {
    float id;
    String nomLivreur;
    String etat;
    String dateLivraison;
    Commande idCommande;

    public Livraison(Commande idCommande, String nomLivreur, String dateLivraison,String etat) {
        this.nomLivreur = nomLivreur;
        this.etat = etat;
        this.dateLivraison = dateLivraison;
        this.idCommande = idCommande;
    }

    

    public Livraison(float id, String nomLivreur, String etat, String dateLivraison,Commande idCommande) {
        this.id = id;
        this.nomLivreur = nomLivreur;
        this.etat = etat;
        this.dateLivraison = dateLivraison;
        this.idCommande = idCommande;
    }

    public Commande getIdCommande() {
        return idCommande;
    }

    public void setIdCommande(Commande idCommande) {
        this.idCommande = idCommande;
    }

    public Livraison() {
    }

    
    public float getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNomLivreur() {
        return nomLivreur;
    }

    public void setNomLivreur(String nomLivreur) {
        this.nomLivreur = nomLivreur;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public String getDateLivraison() {
        return dateLivraison;
    }

    public void setDateLivraison(String dateLivraison) {
        this.dateLivraison = dateLivraison;
    }
    
    

}
